package com.tntra.pargo.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.tntra.pargo.R

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
    }
}