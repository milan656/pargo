package com.tntra.pargo.activity

import android.Manifest
import androidx.lifecycle.viewModelScope;
import androidx.lifecycle.ViewModelProviders
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.core.app.ActivityCompat
import androidx.lifecycle.Observer
import com.tntra.pargo.common.Common
import com.tntra.pargo.common.Common.Companion.showDialogue
import com.tntra.pargo.common.PrefManager
import com.tntra.pargo.viewmodel.LoginActivityViewModel
import com.google.android.gms.auth.api.phone.SmsRetriever
import com.google.gson.JsonObject
import io.agora.openlive.R

class LoginActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var loginViewModel: LoginActivityViewModel
    private lateinit var prefManager: PrefManager
    private lateinit var edtLoginEmail: EditText

    private lateinit var btnLoginToDashBoard: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        init()

        smsPermission()

        try {
            Common.isCalling = false
        } catch (e: Exception) {
            e.printStackTrace()
        }

        loginViewModel = ViewModelProviders.of(this).get(LoginActivityViewModel::class.java)

    }

    private fun init() {
        prefManager = PrefManager(this@LoginActivity)

        edtLoginEmail = findViewById<EditText>(R.id.edtLoginEmail)

        btnLoginToDashBoard = findViewById(R.id.btnLoginToDashBoard)
        btnLoginToDashBoard.setOnClickListener(this)

    }
    private fun smsPermission() {
        val pERMISSIONS = arrayOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS
        )
        if (!hasPermissions(this, *pERMISSIONS)) {
            ActivityCompat.requestPermissions(this, pERMISSIONS, 1)
        }
    }

    fun hasPermissions(context: Context?, vararg permissions: String?): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
            for (permission in permissions) {
                if (ActivityCompat.checkSelfPermission(
                        context,
                        permission!!
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    return false
                }
            }
        }
        return true
    }


    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btnLoginToDashBoard -> userLogin()
        }
    }

    private fun userLogin() {
        edtLoginEmail.requestFocus()
        if (edtLoginEmail.text?.trim()?.length == 0) {
            edtLoginEmail.error = "Please Enter Mobile number"
            //Common.showShortToast("Please enter userid", this@LoginActivity)
            return
        }
        if (edtLoginEmail.text?.trim()?.length != 10) {
            edtLoginEmail.error = "Please Enter Valid Mobile number"
            //Common.showShortToast("Please enter userid", this@LoginActivity)
            return
        }

        startSMSListener()

        Common.showLoader(this@LoginActivity)


        val jsonObject = JsonObject()
        jsonObject.addProperty("phone_number", edtLoginEmail.text.toString())
        Log.e("getobject", "" + jsonObject)

        loginViewModel.initTwo(jsonObject)
        loginViewModel.sendOtp()?.observe(this, Observer {
            Common.hideLoader()
            if (it != null) {
                if (it.success) {
                    val intent = Intent(this, VerifyOtpActivity::class.java)
                    intent.putExtra("number", edtLoginEmail.text?.toString())
                    startActivity(intent)
                } else {
                    Common.hideLoader()
                    if (it.error != null && it.error.get(0).message != null) {
                        showDialogue(this,"Oops!",it.error.get(0).message,false)
                    }
                }
            }
        })
    }

    private fun startSMSListener() {
        try {
            val client = SmsRetriever.getClient(this)
            val task = client.startSmsRetriever()
            task.addOnSuccessListener {
                // API successfully started
            }
            task.addOnFailureListener {
                // Fail to start API
            }
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

}