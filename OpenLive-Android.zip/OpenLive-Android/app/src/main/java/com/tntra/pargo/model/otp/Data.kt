package com.walkins.aapkedoorstep.model.login.otp

data class Data(
    val otp: String
)