package com.tntra.pargo.viewmodel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tntra.pargo.repository.LoginRepository
import com.google.gson.JsonObject
import com.jkadvantagandbadsha.model.login.UserModel
import com.walkins.aapkedoorstep.model.login.otp.OtpModel


class LoginActivityViewModel : ViewModel() {

    private var loginRepository: LoginRepository? = null
    var userModelData: MutableLiveData<UserModel>? = null
//    var uploadImageModel: MutableLiveData<UploadImageModel>? = null
    var otpModel: MutableLiveData<OtpModel>? = null


    fun getLoginData(): LiveData<UserModel>? {
        return userModelData
    }



    fun sendOtp(): LiveData<OtpModel>? {
        return otpModel
    }

    fun init(
        userId: String,
        password: String,
        grantType: String,
        authorizationToke: String,
        versionCode: Int,
        deviceName: String?,
        androidOS: String,
        deviceType: String?
    ) {

        loginRepository = LoginRepository().getInstance()
        userModelData = loginRepository!!.loginUser(
            userId,
            password,
            grantType,
            authorizationToke,
            versionCode,
            deviceName,
            androidOS
        )

    }



    fun initTwo(
        jsonObject: JsonObject,

    ) {

        loginRepository = LoginRepository().getInstance()
        otpModel = loginRepository!!.loginUserTwo(
            jsonObject
        )

    }



//    fun uploadImage(
//        multiPart: MultipartBody.Part,
//        authorizationToke: String,
//        context: Context,
//        type: String
//    ) {
//        loginRepository = LoginRepository().getInstance()
//        uploadImageModel =
//            loginRepository?.uploadImage(multiPart, type, authorizationToke, context)
//    }
//
//    fun getImageUpload(): LiveData<UploadImageModel>? {
//        return uploadImageModel!!
//    }


}